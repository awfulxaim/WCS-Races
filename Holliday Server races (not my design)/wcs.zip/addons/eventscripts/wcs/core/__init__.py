import admin
reload(admin)

import changerace
reload(changerace)

import dataAPI
reload(dataAPI)

import effect
reload(effect)

import expand
reload(expand)

import group
reload(group)

import keyAPI
reload(keyAPI)

import playerinfo
reload(playerinfo)

import raceinfo
reload(raceinfo)

import resetskills
reload(resetskills)

import restrict
reload(restrict)

import savexp
reload(savexp)

import shopinfo
reload(shopinfo)

import shopmenu
reload(shopmenu)

import showskills
reload(showskills)

import spendskills
reload(spendskills)

import sqliteAPI
reload(sqliteAPI)

import wcsgroup
reload(wcsgroup)

import wcshelp
reload(wcshelp)

import wcsmenu
reload(wcsmenu)

import wcstop
reload(wcstop)

import welcome
reload(welcome)
